from turtle import title
from django.http import HttpResponse
from urllib import request
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .models import imoveis_s
from .forms import ImovelForm

# Create your views here.
def index(request): 
    busca = request.GET.get('search')
    if busca:
        imoveis_list = imoveis_s.objects.filter(Name__icontains=busca)[:10]   #PRECISA VALIDAR +
        imoveis_html = {'imoveis_s': imoveis_list} 
    else:
        imoveis_list = imoveis_s.objects.all()
        imoveis_html = {'imoveis_s': imoveis_list} 
        if request.method == "GET":
         return render(request, 'login/index.html', imoveis_html)
    return render(request, 'login/index.html', imoveis_html)

def NewImovel(request): 
  imoveis_list = imoveis_s.objects.all()
  imoveis_html = {'imoveis_s': imoveis_list}
  if request.method == 'POST':
        form = ImovelForm(request.POST, request.FILES)
        if form.is_valid():
            imovel = form.save(commit=False)
            imovel.Status = 'Disponível'
            imovel.save()
            return render(request, 'login/index.html', imoveis_html)

  else:
        form = ImovelForm()
        return render(request, 'login/adicionar_imoveis.html', {'form': form})  # Retorna o formulário para preenchimento

def deletarImoveis(request, id):
    imovel_list = get_object_or_404(imoveis_s, pk=id)
    imovel_list.delete()
    return redirect ('/')
    
def vizualizarImoveis(request, id):
    imovel_list = get_object_or_404(imoveis_s, pk=id)
    return render(request, 'login/list.html',{'list':imovel_list})

def editarImoveis(request, id):
    imovel_list = get_object_or_404(imoveis_s, pk=id)
    form = ImovelForm(instance=imovel_list)
    if request.method == 'POST':
        form = ImovelForm(request.POST, request.FILES, instance=imovel_list)
        if form.is_valid():
            form.save()  # Salve o formulário, isso atualizará automaticamente o objeto imovel_list
            return redirect('/')
    else:
        return render(request, 'login/edit-imovel.html', {'form': form, 'list': imovel_list})

def loginn(request):
    if request.method == "GET":
        return render(request, 'login/loginn.html')
    else:
        username = request.POST.get('loginuser')
        senha = request.POST.get('senhauser')
        user = authenticate(username=username, password=senha)
        if user is not None:
            login(request, user)
            return HttpResponse("logado")
        else:
            return HttpResponse("erro")

def cadastro(request):
    if request.method == "GET":
        return render(request, 'login/cadastro.html')
    elif request.method == "POST":
        username = request.POST.get('loginuser')
        senha = request.POST.get('senhauser')
        
        # Verifica se o usuário já existe
        if User.objects.filter(username=username).exists():
            # Faça o tratamento adequado (redirecionar com uma mensagem de erro, por exemplo)
            return render(request, 'login/cadastro.html')

        user = User.objects.create_user(username=username, password=senha)
        user.save()

        # Redireciona para uma página de sucesso ou outra ação desejada
        return render(request, 'login/cadastro.html')