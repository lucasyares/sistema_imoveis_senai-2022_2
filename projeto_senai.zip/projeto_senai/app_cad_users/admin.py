from django.contrib import admin
from .models import imoveis_s

admin.site.register(imoveis_s)
# Register your models here.
