from dataclasses import fields
from pydoc import describe
from django import forms
from .models import imoveis_s

class ImovelForm(forms.ModelForm):
    class Meta:
        model = imoveis_s
        fields = ['Name', 'Descrption', 'Foto']
    